from django.contrib import admin
from . import models


admin.site.register(models.Banner)
admin.site.register(models.Result)
admin.site.register(models.Team)
admin.site.register(models.Service)
admin.site.register(models.Blog)
admin.site.register(models.Contact)






